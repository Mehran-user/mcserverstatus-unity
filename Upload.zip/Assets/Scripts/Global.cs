using System.Net.Mime;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using TMPro;

[System.Serializable]
public class ServerStatus
{
    public bool online;
    public string host;
    public int port;
    public VersionInfo version;
    public PlayersInfo players;
    public string edition;
    public MotdInfo motd;
}

[System.Serializable]
public class VersionInfo
{
    public string name;
}

[System.Serializable]
public class PlayersInfo
{
    public int online;
    public int max;
}

[System.Serializable]
public class MotdInfo
{
    public string raw;
    public string clean;
}

public class Global : MonoBehaviour
{
    // Store output values
    public bool isOnline;
    public string host;
    public int port;
    public string versionName;
    public string playersOnline;
    public string playersMax;
    public string edition;
    public string world;

    // Set the output values
    public TMP_Text isOnlinetext;
    public TMP_Text hosttext;
    public TMP_Text porttext;
    public TMP_Text versiontext;
    public TMP_Text playersOnlinetext;
    public TMP_Text playersMaxtext;
    public TMP_Text editiontext;
    public TMP_Text worldtext;

    void Start(){
        SOMETHING();
    }

    void SOMETHING()
    {
        StartCoroutine(CheckServerStatus());
    }

    IEnumerator CheckServerStatus()
    {
        string url = "https://api.mcstatus.io/status/bedrock/if-necklace.gl.at.ply.gg:35024";

        UnityWebRequest request = UnityWebRequest.Get(url);
        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Error: " + request.error);
            yield break;
        }

        string json = request.downloadHandler.text;
        ServerStatus status = JsonUtility.FromJson<ServerStatus>(json);

        // Always present
        isOnline = status.online;
        host = status.host;
        port = status.port;

        string motdClean = "-";

        if (status.online)
        {
            versionName = status.version != null ? status.version.name : "-";
            playersOnline = status.players != null ? status.players.online.ToString() : "-";
            playersMax = status.players != null ? status.players.max.ToString() : "-";
            edition = !string.IsNullOrEmpty(status.edition) ? status.edition : "-";
            motdClean = status.motd != null ? status.motd.clean : "-";
        }
        else
        {
            versionName = "-";
            playersOnline = "-";
            playersMax = "-";
            edition = "-";
            motdClean = "-";
        }

        // World Handling
        string[] parts = motdClean.Split('\n');
        string finalizedmotd = parts.Length > 1 ? parts[1] : parts[0];

        // (Optional) Debug log
        Debug.Log($"Online: {isOnline}");
        Debug.Log($"Host: {host}");
        Debug.Log($"Port: {port}");
        Debug.Log($"Version: {versionName}");
        Debug.Log($"Players Online: {playersOnline}");
        Debug.Log($"Max Players: {playersMax}");
        Debug.Log($"Edition: {edition}");
        Debug.Log($"World: {finalizedmotd}");

        // Set the values
        hosttext.text = host;
        porttext.text = port.ToString();
        versiontext.text = versionName;
        playersOnlinetext.text = playersOnline;
        playersMaxtext.text = playersMax;
        editiontext.text = edition;
        worldtext.text = finalizedmotd;
        isOnlinetext.text = isOnline ? "Online" : "Offline";
        yield return new WaitForSeconds(5);
        SOMETHING();
    }

    public void AddNewServer()
    {
        Application.OpenURL("minecraft:?AddExternalServer=Amazing server|if-necklace.gl.at.ply.gg:35024");
        Debug.Log("Tried to send intent");
    }

    public void SwitchToScene(int scene)
    {
        SceneManager.LoadScene(scene);
        Debug.Log("Loaded scene " + scene);
    }

    // Copy with the press of a button
    public void Copy(int id)
    {
        if (id == 0)
        {
            GUIUtility.systemCopyBuffer = host;
            Debug.Log("Copied host: " + host);
        }
        else if (id == 1)
        {
            GUIUtility.systemCopyBuffer = port.ToString();
            Debug.Log("Copied port: " + port);
        }
        else
        {
            Debug.LogError("Copy ID should be 0 (host) or 1 (port).");
        }
    }

    // Quit
    public void Quit(){
        Application.Quit();
        Debug.Log("This is where the application would Quit");
    }
}
